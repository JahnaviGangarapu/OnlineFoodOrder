package com.onlinefoodorder.onlinefoodorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinefoodorderApplicationTests {

	@Test
	void contextLoads() {
	}

}
